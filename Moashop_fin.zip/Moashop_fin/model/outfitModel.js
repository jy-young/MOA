const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    gen:String,
    rank:String,
    name:String,
    age:String,
    category:String,  
    src:String  
})

const Outfit = mongoose.model('Outfit',schema);

module.exports = Outfit;