var Outfit = require('../model/outfitModel');

//create and save 
exports.create = (req,res)=>{
    if(!req.body){
        res.status(400).send();
        return;
    }

    const outfit = new Outfit({
        gen:req.body.gen,
        rank:req.body.rank,
        name:req.body.name,
        age:req.body.age,
        category:req.body.category,
        src:req.body.src,
    })

    outfit
        .save(outfit)
        .then(data => {
            //res.send(data)
            res.redirect('/outfit/add')
        })
        .catch(err=>{
            res.status(500)
        })
}

exports.find = (req,res)=>{
    if(req.query.id){
        const id = req.query.id;

        Outfit.findById(id)
            .then(outfit =>{
                if(!outfit){
                    res.status(404).send({message: `Cannot find ${id}`})
                }else{
                    res.send(outfit)
                }
            })
            .catch(err=>{
                res.status(500)
            })

    }else{
        Outfit.find()
        .then(outfit =>{
            res.send(outfit)
        })
        .catch(err=>{
            res.status(500)
        })
    }
    
}

exports.update = (req,res)=>{
    if(!req.body){
        return res.status(400)
    }
    const id = req.params.id;
    Outfit.findByIdAndUpdate(id, req.body, {useFindAndModify:false})
        .then(outfit => {
            if(!outfit){
                res.status(404).send({message: `Cannot find ${id}`})
            }else{
                res.send(outfit)
            }
        })
        .catch(err =>{
            res.status(500)
        })
}

exports.delete = (req,res)=>{
    const id = req.params.id;

    Outfit.findByIdAndDelete(id)
        .then(outfit => {
            if(!outfit){
                res.status(404).send({message: `Cannot find ${id}`})
            }else{
                res.send({
                    message:"Delete Success"
                })
            }
        })
        .catch(err => {
            res.status(500)
        })
}